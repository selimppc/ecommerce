var $item_price = "$" + Math.random().toFixed(4);
//alert('hello');