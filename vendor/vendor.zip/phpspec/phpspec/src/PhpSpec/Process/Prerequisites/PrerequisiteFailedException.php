<?php

namespace PhpSpec\Process\Prerequisites;


class PrerequisiteFailedException extends \Exception
{
} 